﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;

namespace Csharp正则测试
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //by:Toto
            //邮箱：totomike@163.com
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

       

        private void button1_Click(object sender, EventArgs e)//进行全部匹配
        {
            richTextBox3.Text = "";
            if (richTextBox1.Text == "")
            {
                MessageBox.Show("原始数据为空，请输入原始数据");
            }
            int a = 0;
          
            try
            {
                Regex r = new Regex(richTextBox2.Text);//正则表达式
                foreach (Match m in r.Matches(richTextBox1.Text))//匹配
                {
                    a++;
                    richTextBox3.Text = richTextBox3.Text + m.Value + "\r\n";
                   
                }
               
                string b = "";
                b = richTextBox3.Text.Replace("\r\n", "");
                label3.Text = "长度" + b.Length.ToString();//计算编码长度

                label4.Text = "数量："+a.ToString();//计算所匹配的数量
                //if (textBox3.Text == "") ;
               // return(textBox3.Text=="");
              /*  if (richTextBox3.Text == "")
                {
                    MessageBox.Show("匹配失败！\r\n请检查");
                }
                */
                
            }
            catch {
              /*  if (richTextBox3.Text == "")
                {

                    MessageBox.Show("正则表达式有问题");
                }*/
            }
        }



        private void button2_Click(object sender, EventArgs e)//单个匹配
        {

            richTextBox3.Text = "";
            
            if (richTextBox1.Text == "")
            {
                MessageBox.Show("原始数据为空，请输入原始数据");
            }
            try
            {
                int a = 1;
                Regex r = new Regex(richTextBox2.Text);
                Match m = r.Match(richTextBox1.Text);
               /* if (!m.Success || m.Value == null)
                {
                    MessageBox.Show("匹配失败！\r\n请检查");
                    int c = 0;
                    label4.Text = "数量：" + c;

                }*/
                richTextBox3.Text = m.Value;
              
                label3.Text = m.Value.Count().ToString();
                //a = textBox3.Text.Length
                label4.Text = "数量："+a.ToString();
            
            }
            catch {
                int a = 0;
                label4.Text = "数量：" + a.ToString();
                //    MessageBox.Show("正则表达式有问题");
                
            }
            string b = "";
            b = richTextBox3.Text.Replace("\r\n", "");
            label3.Text = "长度" + b.Length.ToString();//计算编码长度
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

      

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
           
        }
        
        private void button3_Click(object sender, EventArgs e)    //richTextBox中的字符串查找
        {
            
               // richTextBox4.Text = "";
           // int StartIndex = 0;
                if (richTextBox4.Text == "")
                {
                    MessageBox.Show("请输入要查找的内容");
                }
                try
                {
                  int fm1 = richTextBox1.Find(richTextBox4.Text);
                  //this.richTextBox1.SelectionColor.R;
                 //   int NextPosition = richTextBox1.Find(richTextBox4.Text, FirstPosition + richTextBox4.Text.Length);
                    //this.richTextBox1.SelectionColor.Red;
                   // int index = richTextBox4.Find(richTextBox4.Text,richTextBox1.Find);
                  // fm1.richTextBox1.Focus();
                 /*   string words = this.richTextBox1.Text;//实现向下搜索
                    string TobeFound = this.richTextBox4.Text;
                    if (StartIndex == -1)
                    { //没有发现
                        return;                    
                    
                    }
                    StartIndex = words.IndexOf(TobeFound, StartIndex);
                    if (StartIndex >= 0 && StartIndex < words.Length)
                    {
                        this.richTextBox1.Select(StartIndex, TobeFound.Length);
                        this.richTextBox1.Focus();
                        StartIndex +=TobeFound.Length;
                    }*/
                  //  Int64 SearchPos = richTextBox1.Find(richTextBox4,Int32,Int32, RichTextBoxFinds.Reverse);
                  // int i=100;
                    // i = richTextBox1.Find(richTextBox4.Text, 0,i-1, RichTextBoxFinds.Reverse);
            }
            catch {
               
            
            }

        
        }

        private void richTextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void fileSystemWatcher1_Changed(object sender, FileSystemEventArgs e)
        {

        }
      
        private void button4_Click(object sender, EventArgs e)
        {
           // richTextBox4.Text = "";
            int StartIndex = 0;
            string words = this.richTextBox1.Text;
            string tobefound = this.richTextBox4.Text;
            StartIndex=words.IndexOf(tobefound,StartIndex);
            if (StartIndex >= 0 && StartIndex <= words.Length) {
                this.richTextBox1.Select(StartIndex, tobefound.Length);
                this.richTextBox1.Focus();
                StartIndex -= tobefound.Length;
            }
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
            richTextBox4.Text = "";
        }
      
    
    }
        
        
      
    }
